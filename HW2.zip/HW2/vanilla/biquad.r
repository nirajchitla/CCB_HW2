p 1 : qnext 1 pf_src 1 py_src 1 : 1
q 1 : qf_src 1 qy_src 1 : 1
pf_src 8 : pf 1 : 1
py_src 8 : py 1 : 1
qf_src 8 : qf 1 : 1
qy_src 8 : qy 1 : 1
x 1 : a 1 : 1
pf 1 : a 1 : 1
qf 1 : a 1 : 1
a 1 : pnext 1 ay_src 1 : 1
ay_src 8 : ay 1 : 1
ay 1 : y 1 : 1
py 1 : y 1 : 1
qy 1 : y 1 : 1